% Main camera calibration toolbox:

path(pwd,path);

format compact
